this["RB"] = this["RB"] || {};
this["RB"]["templates"] = this["RB"]["templates"] || {};
this["RB"]["templates"]["boxes"] = this["RB"]["templates"]["boxes"] || {};
this["RB"]["templates"]["boxes"]["create"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return "<h1>Add Box</h1>\n<p>Add a box to your collection here.</p>\n<form id=\"boxes--create\" action=\"/users/1/boxes\" method=\"post\" >\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"box-name\" class=\"text-right middle\">Box Name</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <input type=\"text\" name=\"name\" id=\"box-name\" placeholder=\"Name (will appear on box selection navigation)\" aria-describedby=\"help--boxes-form--box-name\">\n      <p class=\"help-text\" id=\"help--boxes-form--box-name\">The name that will appear in the boxes navigation and any box selection interface.</p>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"box-desc\" class=\"text-right middle\">Box Description</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <textarea name=\"desc\" id=\"box-desc\"></textarea>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <input type=\"hidden\" name=\"read_order\" value=\"9999\" />\n    </div>\n    <div class=\"small-9 columns\">\n      <button type=\"submit\" class=\"success button ajax-create-submit\">Save</button>\n    </div>\n  </div>\n</form>";
},"useData":true});
this["RB"]["templates"]["boxes"]["edit"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<h1>Edit Box</h1>\n<form id=\"boxes--update\" action=\"/users/1/boxes/"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" method=\"patch\">\n	<div class=\"row\">\n		<div class=\"small-3 columns\">\n			<label for=\"box-name\" class=\"text-right middle\">Box Name</label>\n		</div>\n		<div class=\"small-9 columns\">\n			<input type=\"text\" name=\"name\" id=\"box-name\" placeholder=\"Name (will appear on box selection navigation)\" aria-describedby=\"help--boxes-form--box-name\" value=\""
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "\">\n			<p class=\"help-text\" id=\"help--boxes-form--box-name\">The name that will appear in the boxes navigation and any box selection interface.</p>\n		</div>\n	</div>\n	<div class=\"row\">\n		<div class=\"small-3 columns\">\n			<label for=\"box-desc\" class=\"text-right middle\">Box Description</label>\n		</div>\n		<div class=\"small-9 columns\">\n			<textarea name=\"desc\" id=\"box-desc\">"
    + alias3(((helper = (helper = helpers.desc || (depth0 != null ? depth0.desc : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"desc","hash":{},"data":data}) : helper)))
    + "</textarea>\n		</div>\n	</div>\n	<div class=\"row\">\n		<div class=\"small-3 columns\"></div>\n		<div class=\"small-9 columns\">\n			<button type=\"submit\" class=\"success button ajax-update-submit\">Save</button>\n		</div>\n	</div>\n</form>\n";
},"useData":true});
this["RB"]["templates"]["boxes"]["recipeRow"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<tr>\n	<td><a href=\"/recipes/view.html?recipeId="
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "</a></td>\n	<td>"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers.serving || (depth0 != null ? depth0.serving : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"serving","hash":{},"data":data}) : helper)))
    + "</td>\n</tr>";
},"useData":true});
this["RB"]["templates"]["boxes"]["tab"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<li class=\"tabs-title\" role=\"presentation\" data-box-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n	<a href=\"#box-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" aria-selected=\"false\" role=\"tab\" aria-controls=\"box-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" id=\"box-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "-label\">"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</a>\n</li>";
},"useData":true});
this["RB"]["templates"]["boxes"]["tabPanel"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"tabs-panel\" id=\"box-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" role=\"tabpanel\" aria-hidden=\"true\" aria-labelledby=\"box-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "-label\">\n	<a href=\"/users/1/boxes/"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" class=\"boxes--remove\">\n		<svg class=\"icon icon-cross\"><use xlink:href=\"#icon-cross\"></use></svg>\n	</a>\n	<a href=\"/users/1/boxes/"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" class=\"drawer-trigger\" data-template=\"boxes.edit\">\n		<svg class=\"icon icon-pencil\"><use xlink:href=\"#icon-pencil\"></use></svg> \n	</a>\n\n  	<p>"
    + alias3(((helper = (helper = helpers.desc || (depth0 != null ? depth0.desc : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"desc","hash":{},"data":data}) : helper)))
    + "</p>\n\n  	<h2>Recipes</h2>\n    <button type=\"button\" class=\"recipes--new\" data-box-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">Add Recipe</button>\n\n  	<table class=\"recipes-listing\">\n  		<thead>\n  			<tr>\n          <th>\n            ID\n          </th>\n  				<th>\n  				 	Name\n  				</th>\n  				<th>\n  					Serving\n  				</th>\n  			</tr>\n  		</thead>\n      <tbody>\n      </tbody>\n  	</table>\n</div>\n\n";
},"useData":true});
this["RB"]["templates"]["ingredients"] = this["RB"]["templates"]["ingredients"] || {};
this["RB"]["templates"]["ingredients"]["row"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<tr data-ingredient-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n	<td>"
    + alias3(((helper = (helper = helpers.quantity || (depth0 != null ? depth0.quantity : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"quantity","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers.unit || (depth0 != null ? depth0.unit : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"unit","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers.modifier || (depth0 != null ? depth0.modifier : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"modifier","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers.ingredient || (depth0 != null ? depth0.ingredient : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"ingredient","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers.treatment || (depth0 != null ? depth0.treatment : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"treatment","hash":{},"data":data}) : helper)))
    + "</td>\n	<td><button type=\"button\">Remove</button></td>\n</tr>";
},"useData":true});
this["RB"]["templates"]["recipes"] = this["RB"]["templates"]["recipes"] || {};
this["RB"]["templates"]["recipes"]["instructionRow"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<tr data-instruction-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n	<td>"
    + alias3(((helper = (helper = helpers.text || (depth0 != null ? depth0.text : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"text","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers['active-time'] || (depth0 != null ? depth0['active-time'] : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"active-time","hash":{},"data":data}) : helper)))
    + "</td>\n	<td>"
    + alias3(((helper = (helper = helpers['total-time'] || (depth0 != null ? depth0['total-time'] : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"total-time","hash":{},"data":data}) : helper)))
    + "</td>\n	<td><button type=\"button\">Remove</button></td>\n</tr>";
},"useData":true});
this["RB"]["templates"]["recipes"]["maint"] = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, alias1=this.lambda, alias2=this.escapeExpression;

  return "          <option value=\""
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.attributes : depth0)) != null ? stack1.id : stack1), depth0))
    + "\">"
    + alias2(alias1(((stack1 = (depth0 != null ? depth0.attributes : depth0)) != null ? stack1.name : stack1), depth0))
    + "</option>\n";
},"3":function(depth0,helpers,partials,data) {
    var helper;

  return "        <input type=\"hidden\" name=\"id\" value=\""
    + this.escapeExpression(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<h1>Add Recipe</h1>\n<p>Add a recipe to your collection here.</p>\n<form id=\"recipes--maint\" action=\"/recipes\" method=\"post\" >\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"recipe-name\" class=\"text-right middle\">Recipe Name</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <input type=\"text\" name=\"name\" id=\"recipe-name\" placeholder=\"Name of recipe\" aria-describedby=\"help--boxes-form--box-name\" value=\""
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "\">\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"recipe-intro\" class=\"text-right middle\">Introduction</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <textarea name=\"intro\" id=\"recipe-intro\">"
    + alias3(((helper = (helper = helpers.intro || (depth0 != null ? depth0.intro : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"intro","hash":{},"data":data}) : helper)))
    + "</textarea>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"recipe-image-path\" class=\"text-right middle\">Image</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <input type=\"text\" name=\"image_path\" id=\"recipe-image-path\" placeholder=\"Path to image\" aria-describedby=\"help--boxes-form--box-name\" value=\""
    + alias3(((helper = (helper = helpers.image_path || (depth0 != null ? depth0.image_path : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"image_path","hash":{},"data":data}) : helper)))
    + "\">\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"box-name\" class=\"text-right middle\">Box</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <select name=\"box_id\">\n"
    + ((stack1 = helpers.each.call(depth0,(depth0 != null ? depth0.boxes : depth0),{"name":"each","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "      </select>\n      <p class=\"help-text\" id=\"help--boxes-form--box-name\">The name that will appear in the boxes navigation and any box selection interface.</p>\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <label for=\"serving-size\" class=\"text-right middle\">Serving Size</label>\n    </div>\n    <div class=\"small-9 columns\">\n      <input type=\"text\" name=\"serving\" id=\"serving-size\" placeholder=\"Number of people served or quantity of recipe\" aria-describedby=\"help--boxes-form--box-name\" value="
    + alias3(((helper = (helper = helpers.serving || (depth0 != null ? depth0.serving : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"serving","hash":{},"data":data}) : helper)))
    + ">\n    </div>\n  </div>\n  <div class=\"row\">\n    <div class=\"small-3 columns\">\n      <input type=\"hidden\" name=\"creator_id\" value=\"1\" />\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.id : depth0),{"name":"if","hash":{},"fn":this.program(3, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "    </div>\n    <div class=\"small-9 columns\">\n      <button type=\"submit\" class=\"success button ajax-create-submit\">Save</button>\n    </div>\n  </div>\n</form>";
},"useData":true});
this["RB"]["templates"]["recipes"]["sectionTab"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<li class=\"tabs-title\" role=\"presentation\" data-section-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n	<a href=\"#section-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" aria-selected=\"false\" role=\"tab\" aria-controls=\"section-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" id=\"section-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "-label\">"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</a>\n</li>";
},"useData":true});
this["RB"]["templates"]["recipes"]["sectionTabPanel"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<div class=\"tabs-panel\" id=\"section-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\" role=\"tabpanel\" aria-hidden=\"true\" aria-labelledby=\"section-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "-label\">\n	<div class=\"row\">\n		<div class=\"small-6 columns\">\n			<form id=\"ingredients--maint\" action=\"/recipes/"
    + alias3(((helper = (helper = helpers.recipeId || (depth0 != null ? depth0.recipeId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"recipeId","hash":{},"data":data}) : helper)))
    + "/sections/"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "/ingredients\" class=\"ingredients-listing\">	\n				<h4>Ingredients</h4>\n				<table>\n					<thead>\n						<tr>\n							<th class=\"text-center\">Quantity</th>\n							<th class=\"text-center\">Unit</th>\n							<th class=\"text-center\">Modifier</th>\n							<th class=\"text-center\">Ingredient</th>\n							<th class=\"text-center\">Treatment</th>\n							<th class=\"text-center\">Actions</th>\n						</tr>\n					</thead>\n					<tbody></tbody>\n					<tfoot>\n						<tr>\n							<td>\n								<input type=\"text\" name=\"quantity\">\n							</td>\n							<td>\n								<input type=\"text\" name=\"unit\">\n							</td>\n							<td>\n								<input type=\"text\" name=\"modifier\">\n							</td>\n							<td>\n								<input type=\"text\" name=\"ingredient\">\n							</td>\n							<td>\n								<input type=\"text\" name=\"treatment\">\n							</td>\n							<td>\n								<input type=\"hidden\" name=\"section_id\" value=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n								<button type=\"submit\">Save</button>\n							</td>\n						</tr>\n					</tfoot>\n				</table>\n			</form>\n		</div><!-- /.small-6 columns -->\n		<div class=\"small-6 columns\">\n			<form id=\"instructions--maint\" action=\"/recipes/"
    + alias3(((helper = (helper = helpers.recipeId || (depth0 != null ? depth0.recipeId : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"recipeId","hash":{},"data":data}) : helper)))
    + "/sections/"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "/instructions\" class=\"instructions-listing\">	\n				<h4>Instructions</h4>\n				<table>\n					<thead>\n						<tr>\n							<th rowspan=\"2\" class=\"text-center\">Step</th>\n							<th colspan=\"2\" class=\"text-center\">Time</th>\n							<th rowspan=\"2\" class=\"text-center\">Actions</th>\n						</tr>\n						<tr>\n							<th class=\"text-center\">Active</th>\n							<th class=\"text-center\">Total</th>\n						</tr>\n					</thead>\n					<tbody></tbody>\n					<tfoot>\n						<tr>\n							<td>\n								<textarea name=\"text\" id=\"step-text\" cols=\"30\" rows=\"3\"></textarea>\n							</td>\n							<td>\n								<input type=\"number\" name=\"active_time\">\n							</td>\n							<td>\n								<input type=\"number\" name=\"total_time\">\n							</td>\n							<td>\n								<input type=\"hidden\" name=\"section_id\" value=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\">\n								<input type=\"hidden\" name=\"order\" value=\"4\">\n								<button type=\"submit\">Save</button>\n							</td>\n						</tr>\n					</tfoot>\n				</table>\n			</form>\n		</div><!-- /.small-6 columns -->\n	</div>\n</div>\n";
},"useData":true});
this["RB"]["templates"]["recipes"]["view"] = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "<h3>"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</h3>\n<button type=\"button\" class=\"recipes--edit\" data-recipe-id=\""
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "\"><svg class=\"icon icon-pencil\"><use xlink:href=\"#icon-pencil\"></use></svg></button>\n<p>Serves: "
    + alias3(((helper = (helper = helpers.serving || (depth0 != null ? depth0.serving : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"serving","hash":{},"data":data}) : helper)))
    + "</p>\n<p>"
    + alias3(((helper = (helper = helpers.intro || (depth0 != null ? depth0.intro : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"intro","hash":{},"data":data}) : helper)))
    + "</p>\n<p><img src=\""
    + alias3(((helper = (helper = helpers.image_path || (depth0 != null ? depth0.image_path : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"image_path","hash":{},"data":data}) : helper)))
    + "\" /></p>\n<div class=\"row collapse\">\n  <div class=\"medium-1 columns\">\n    <ul class=\"tabs vertical\" id=\"sections-tabset\"></ul>\n  </div>\n  <div class=\"medium-11 columns\">\n    <div id=\"sections-tabset-content\" class=\"tabs-content vertical\" data-tabs-content=\"sections-tabset\"></div>\n  </div>\n</div>";
},"useData":true});